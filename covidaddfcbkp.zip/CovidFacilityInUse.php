<?php
session_start();
if(!isset($_SESSION['ses_loginid'])){
	header("location:index.php");
	exit;
}
$loginid=$_SESSION['ses_loginid'];
include("connection.php");
//get the existing details of facilities
$sql_facilities="select * from m_ccused where loginid=?";
$data=array($loginid);
$format=array("d");
$facility=$db->selectData($sql_facilities,$data,$format);
?>
<html lang="en">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="">

    <title>Login to Pradesh Raksha</title>


    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
  <style>
   form .error{color:#ff0000;}
  </style>
  

  
  <div class="container py-5">
  <div class="row">
        <div class="col-md-12">
         
            <div class="row">
               <div class="col-md-8 offset-md-2">
                    <span class="anchor" id="formAdd"></span>
                    <!-- <hr class="mb-5"> -->

                    <!-- form card change password -->
                    <div class="card card-outline-secondary">
                        <div class="card-header">
                            <h3 class="mb-0">COVID CENTERS</h3>
                        </div>
                        <div class="card-body">
                            <form class="form" role="form" action="serviceCovidFacilityInUse.php" autocomplete="off" id="frmAdd" name="frmAdd" novalidate="" method="POST">
                           
                               
                                

                                <div class="form-group row text-center">

                                <label  class="col-lg-10 col-form-label form-control-label" > <h4>No of Inmates Present at CCC</h4></label>
                                 </div>
                                <div class="form-group row">

                                    <label  class="col-lg-4 col-form-label form-control-label" for="nM1">No. of Male</label>
                                    <div class="col-lg-5">
                                    <input type="text"  maxlength="5"class="form-control" id="nM1" name="nM1">
                                    
                                        </div>
                                </div>
                                <div class="form-group row">

                                     <label class="col-lg-4 col-form-label form-control-label" for="nF1">No. of Females</label>
                                     <div class="col-lg-5">
                                     <input type="text" maxlength="5"class="form-control" id="nF1" name="nF1">
                                     </div>
                                </div>

                                <div class="form-group row">

                                  <label  class="col-lg-4 col-form-label form-control-label" for="tIn1">Total No of Inmates</label>
                                   <div class="col-lg-5">
                                  <input type="text" maxlength="5" class="form-control" id="tIn1" name="tIn1">

                                   </div>
                                </div>

                                  <div class="form-group row text-center">

                                <label  class="col-lg-10 col-form-label form-control-label" for="numIcube"> <h4>Type of Inmates Released as of today</h4></label>
                                 </div>
                                
                                <div class="form-group row">

                                    <label  class="col-lg-4 col-form-label form-control-label" for="nM2">No. of Male</label>
                                    <div class="col-lg-5">
                                    <input type="text"  maxlength="5"class="form-control" id="nM2" name="nM2">
                                    
                                        </div>
                                </div>
                                <div class="form-group row">

                                     <label class="col-lg-4 col-form-label form-control-label" for="nF2">No. of Females</label>
                                     <div class="col-lg-5">
                                     <input type="text" maxlength="5"class="form-control" id="nF2" name="nF2">
                                     </div>
                                </div>

                                <div class="form-group row">

                                  <label  class="col-lg-4 col-form-label form-control-label" for="tIn2">Total No of Inmates</label>
                                   <div class="col-lg-5">
                                  <input type="text" maxlength="5" class="form-control" id="tIn2" name="tIn2">

                                   </div>
                                </div>

                                <div class="form-group row text-center">

                                <label  class="col-lg-10 col-form-label form-control-label" for="numIcube"> <h4>Types of Inmates Present at CCC today</h4></label>
                                 </div>
                                
                                <div class="form-group row">

                                    <label  class="col-lg-4 col-form-label form-control-label" for="nP">No of Pravasis</label>
                                    <div class="col-lg-5">
                                    <input type="text"  maxlength="5"class="form-control" id="nP" name="nP">
                                    
                                        </div>
                                </div>
                                <div class="form-group row">

                                     <label class="col-lg-4 col-form-label form-control-label" for="nIs">No. of Inter State Persons</label>
                                     <div class="col-lg-5">
                                     <input type="text" maxlength="5"class="form-control" id="nIs" name="nIs">
                                     </div>
                                </div>


                                  <div class="form-group row text-center">

                                <label  class="col-lg-10 col-form-label form-control-label" for="numIcube"> <h4> Symptomatic</h4></label>
                                 </div>
                                
                                <div class="form-group row">

                                    <label  class="col-lg-4 col-form-label form-control-label" for="nM3">No. of Male</label>
                                    <div class="col-lg-5">
                                    <input type="text"  maxlength="5"class="form-control" id="nM3" name="nM3">
                                    
                                        </div>
                                </div>
                                <div class="form-group row">

                                     <label class="col-lg-4 col-form-label form-control-label" for="nF3">No. of Females</label>
                                     <div class="col-lg-5">
                                     <input type="text" maxlength="5"class="form-control" id="nF3" name="nF3">
                                     </div>
                                </div>

                                <div class="form-group row">

                                  <label  class="col-lg-4 col-form-label form-control-label" for="tIn3">Total No of Inmates</label>
                                   <div class="col-lg-5">
                                  <input type="text" maxlength="5" class="form-control" id="tIn3" name="tIn3">

                                   </div>
                                </div>
                                  <div class="form-group row text-center">

                                <label  class="col-lg-10 col-form-label form-control-label" for="numIcube"> <h4>Test Done</h4></label>
                                 </div>
                                
                                <div class="form-group row">

                                    <label  class="col-lg-4 col-form-label form-control-label" for="nM4">No. of Male</label>
                                    <div class="col-lg-5">
                                    <input type="text"  maxlength="5"class="form-control" id="nM4" name="nM4">
                                    
                                        </div>
                                </div>
                                <div class="form-group row">

                                     <label class="col-lg-4 col-form-label form-control-label" for="nF4">No. of Females</label>
                                     <div class="col-lg-5">
                                     <input type="text" maxlength="5"class="form-control" id="nF4" name="nF4">
                                     </div>
                                </div>

                                <div class="form-group row">

                                  <label  class="col-lg-4 col-form-label form-control-label" for="tIn4">Total No of Inmates</label>
                                   <div class="col-lg-5">
                                  <input type="text" maxlength="5" class="form-control" id="tIn4" name="tIn4">

                                   </div>
                                </div>

                                <div class="form-group row text-center">

<label  class="col-lg-10 col-form-label form-control-label" for="numIcube"> <h4>Room Details</h4></label>
 </div>
 <div class="form-group row">

     <label class="col-lg-4 col-form-label form-control-label" for="nTr3">No. of Total Rooms</label>
     <div class="col-lg-5">
     <input type="text" maxlength="5"class="form-control" id="nTr3" name="nTr3">
     </div>
</div>

<div class="form-group row">

  <label  class="col-lg-4 col-form-label form-control-label" for="nRo3">No of Rooms Occupied</label>
   <div class="col-lg-5">
  <input type="text" maxlength="5" class="form-control" id="nRo3" name="nRo3">

   </div>
</div>
                            
                                <div class="form-group row">
                                    <label class="col-lg-3 col-form-label form-control-label"></label>
                                    <div class="col-lg-9">
                                    <input type="submit" class="btn btn-primary" id="submitButn" value="Save Data">
                                        <input type="reset" class="btn btn-secondary" id="resetButn" value="Reset Data">
                                       
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <!-- /form card change password -->

                </div>
</div>
</div>
</div>
</div>
<script src="js/jquery-3.2.1.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.validate.min.js"></script>
  <script src="js/additional-methods.js"></script>
  <script>
  $(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='frmAdd']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
     nM1 : {required: true,
      number: true
       },
      nF1  : {required: true,
        number:true
       },
       tIn1 : {required: true,
       number: true
       },
      nP : {required: true,
        number: true
       },
       nIs  : {required: true,
        number:true
       },
      nM2 : {required: true,
       number: true
       },
     nF2 : {required: true,
        number: true
       },
     
     tIn2  : {required: true,
      number: true
        },
       nTr3  : {required: true,
        number: true
        },
       nRo3 : {required: true,
        number: true
        },

        nM3 : {required: true,
      number: true
       },
      nF3  : {required: true,
        number:true
       },
       tIn3 : {required: true,
       number: true
       },
       nM4 : {required: true,
      number: true
       },
      nF4  : {required: true,
        number:true
       },
       tIn4 : {required: true,
       number: true
       },
     

    },
    // Specify validation error messages
    messages: {
        nM1  : {required:"Please enter Number of Males",
          number: " only number is allowed as input"

        },
        nF1 : {required: "Please enter Number of Females",
         number: " only number is allowed as input"
       
      },
      tIn1  : {required:" Please enter Total No of Inmates ",
        number: " only number is allowed as input"

},
nM2  : {required:"Please enter Number of Males",
          number: " only number is allowed as input"

        },
        nF2 : {required: "Please enter Number of Females",
         number: " only number is allowed as input"
       
      },
      tIn2  : {required:" Please enter Total No of Inmates ",
        number: " only number is allowed as input"

},

nM3  : {required:"Please enter Number of Males",
          number: " only number is allowed as input"

        },
        nF3 : {required: "Please enter Number of Females",
         number: " only number is allowed as input"
       
      },
      tIn3  : {required:" Please enter Total No of Inmates ",
        number: " only number is allowed as input"

},
nM4  : {required:"Please enter Number of Males",
          number: " only number is allowed as input"

        },
        nF4 : {required: "Please enter Number of Females",
         number: " only number is allowed as input"
       
      },
      tIn4  : {required:" Please enter Total No of Inmates ",
        number: " only number is allowed as input"

},
nTr3 : {required:"Please enter Total No of Rooms",
  number: " only number is allowed as input"

},
nRo3 : {required: "Please enter No of Rooms Occupied",
         number: " only number is allowed as input"
       
      },
      nP : {required:"Please enter No of Pravasis",
        number: " only number is allowed as input"
      },

      nIs : {required:"Please enter No of Interstate Persons",
  number: " only number is allowed as input"

},

     
  },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
});
  </script>

  
</html>
